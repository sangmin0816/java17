package sec1;

public class Qna {
    public int qno;
    public String title;
    public String content;
    public Qna(int qno, String title, String content){
        this.qno = qno;
        this.title = title;
        this.content = content;
    }
}